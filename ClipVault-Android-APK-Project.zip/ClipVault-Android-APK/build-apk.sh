#!/usr/bin/env bash
set -euo pipefail
echo "Building ClipVault Android APK via Bubblewrap..."
npx @bubblewrap/cli update --manifest="https://ais-dev-voz2hk5fszpxoki6rturfj-895063332490.asia-southeast1.run.app/manifest.webmanifest" || true
npx @bubblewrap/cli build
echo "Done! Look for app-release-signed.apk in this directory."
