# ClipVault — Android APK Project

This bundle contains everything required to generate a signed, installable `ClipVault.apk` for Android pointing to your live ClipVault app (`https://ais-dev-voz2hk5fszpxoki6rturfj-895063332490.asia-southeast1.run.app`).

## Fastest Option 1: Online APK Build (Zero Local Setup)
1. Visit https://www.pwabuilder.com
2. Enter your ClipVault URL: `https://ais-dev-voz2hk5fszpxoki6rturfj-895063332490.asia-southeast1.run.app`
3. Select **Package for Stores -> Android -> Generate Package** to download a ready-to-install signed `.apk`.

## Option 2: Automated GitHub Actions APK Build (Free, Zero Local SDK)
1. Create a GitHub repository and upload the contents of this folder.
2. Open the **Actions** tab and run **Build ClipVault Android APK**.
3. Download `ClipVault-debug.apk` directly from the workflow **Artifacts** section and install it on your Android device.

## Option 3: Local Android Studio / Gradle Build
1. Open the `android/` folder in **Android Studio** (JDK 17 + Android SDK 34).
2. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** (or run `cd android && gradle assembleDebug`).
3. Copy `android/app/build/outputs/apk/debug/app-debug.apk` to your Android phone.

## Option 4: Bubblewrap Trusted Web Activity (TWA)
Run `./build-apk.sh` (requires Node.js 18+ and JDK 17) to build an Android TWA APK from `twa-manifest.json`.
